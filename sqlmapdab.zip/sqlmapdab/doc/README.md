# sqlmap 

    python sqlmap.py -h
    python sqlmap.py -hh

